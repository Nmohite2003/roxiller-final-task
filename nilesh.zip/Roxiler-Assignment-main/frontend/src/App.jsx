import AllRoutes from "./routes/Allroutes";

const App = () => {
  return (
    <div>
      <AllRoutes />
    </div>
  );
};

export default App;
